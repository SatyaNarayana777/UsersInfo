package com.example.usersinfo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private var usersList : List<UserModel>?= null
    private var postsList : List<PostModel>?= null

    private val etNumber : EditText by lazy {
        findViewById(R.id.etNumber)
    }

    private val btnFetch : Button by lazy {
        findViewById(R.id.btnFetch)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val shareService: ApiInterface = retrofit.create(ApiInterface::class.java)

        shareService.getUsers().enqueue(object :Callback<List<UserModel>>{
            override fun onResponse(
                call: Call<List<UserModel>>,
                response: Response<List<UserModel>>
            ) {
                if(response.isSuccessful){
                    if(response.code()==200&&response.body()!=null){
                        usersList = response.body()
                    }
                }else{
                    Toast.makeText(this@MainActivity,"Something went wrong",Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<UserModel>>, t: Throwable) {
                Toast.makeText(this@MainActivity,t.localizedMessage,Toast.LENGTH_SHORT).show()

            }

        })

        shareService.getPosts().enqueue(object : Callback<List<PostModel>>{
            override fun onResponse(
                call: Call<List<PostModel>>,
                response: Response<List<PostModel>>
            ) {
                if(response.isSuccessful){
                    if(response.code()==200&&response.body()!=null){
                        postsList = response.body()
                    }
                }else{
                    Toast.makeText(this@MainActivity,"Something went wrong",Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<PostModel>>, t: Throwable) {
                Toast.makeText(this@MainActivity,t.localizedMessage,Toast.LENGTH_SHORT).show()
            }
        })

        btnFetch.setOnClickListener {

            if(etNumber.text.toString().trim().isEmpty()){
                Toast.makeText(this,"Please enter userid",Toast.LENGTH_SHORT).show()
            }else{
                if(usersList!=null){
                    val user : UserModel? = usersList?.find {
                        it.id == etNumber.text.toString().trim().toString()
                    }

                    val userId = user?.id
                    val userName = user?.name

                    if(userId==null){
                        Toast.makeText(this,"User not found",Toast.LENGTH_SHORT).show()
                    }
                    else{
                        if(postsList!=null){
                            val usersArrayList = arrayListOf<PostModel>()

                            val userPosts = postsList?.filter {
                                it.userId == userId
                            }
                            userPosts?.forEach {
                                it.userName = userName
                                usersArrayList.add(it)
                            }
                            if(userPosts!=null){
                                val intent = Intent(this,PostsActivity::class.java)
                                intent.putParcelableArrayListExtra("POSTS",usersArrayList)
                                startActivity(intent)
                            }else{
                                Toast.makeText(this,"User does not have posts",Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }

    }
}