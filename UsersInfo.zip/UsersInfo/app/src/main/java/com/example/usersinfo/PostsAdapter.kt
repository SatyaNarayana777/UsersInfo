package com.example.usersinfo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostsAdapter(val posts:ArrayList<PostModel>) : RecyclerView.Adapter<PostsAdapter.ViewHolder>() {
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val tvName : TextView = itemView.findViewById(R.id.tvName)
        val tvTitle : TextView = itemView.findViewById(R.id.tvTitle)
        val tvBody : TextView = itemView.findViewById(R.id.tvBody)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view  = LayoutInflater.from(parent.context).inflate(R.layout.row_item_posts,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvName.text = posts[position].userName
        holder.tvTitle.text = posts[position].title
        holder.tvBody.text = posts[position].body
    }

    override fun getItemCount(): Int {
        return posts.size
    }
}