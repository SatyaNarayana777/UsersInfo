package com.example.usersinfo

const val BASE_URL = "https://jsonplaceholder.typicode.com/"